const auth = document.querySelector("#auth");
const dashboard = document.querySelector("#dashboard");
const form = document.querySelector("#authForm");
const message = document.querySelector("#message");
let mode = "login";

function setMode(next) {
  mode = next;
  document.querySelector("#loginTab").classList.toggle("selected", mode === "login");
  document.querySelector("#signupTab").classList.toggle("selected", mode === "signup");
  document.querySelector("#nameLabel").classList.toggle("hidden", mode !== "signup");
  document.querySelector("#formTitle").textContent = mode === "login" ? "Welcome back" : "Create your account";
  document.querySelector("#formHint").textContent = mode === "login" ? "Log in to your NovaCrypto demo account." : "Sign up to create a demo account.";
  document.querySelector("#submitBtn").textContent = mode === "login" ? "Log in" : "Create account";
  document.querySelector("#password").autocomplete = mode === "login" ? "current-password" : "new-password";
  message.textContent = "";
}
document.querySelector("#loginTab").addEventListener("click", () => setMode("login"));
document.querySelector("#signupTab").addEventListener("click", () => setMode("signup"));

function getUsers() { try { return JSON.parse(localStorage.getItem("nova_demo_users") || "{}"); } catch { return {}; } }
function showDashboard(user) {
  auth.classList.add("hidden");
  dashboard.classList.remove("hidden");
  document.querySelector("#userName").textContent = user.name || user.email.split("@")[0];
}
function showAuth() { dashboard.classList.add("hidden"); auth.classList.remove("hidden"); }
form.addEventListener("submit", (event) => {
  event.preventDefault();
  const email = document.querySelector("#email").value.trim().toLowerCase();
  const password = document.querySelector("#password").value;
  const name = document.querySelector("#name").value.trim();
  const users = getUsers();
  if (mode === "signup") {
    if (!name) { message.textContent = "Please enter your name."; return; }
    if (users[email]) { message.textContent = "An account with that email already exists. Please log in."; return; }
    // Demo-only storage: passwords are not securely protected in this browser prototype.
    users[email] = { name, password };
    localStorage.setItem("nova_demo_users", JSON.stringify(users));
    localStorage.setItem("nova_demo_session", email);
    showDashboard(users[email]);
  } else {
    if (!users[email] || users[email].password !== password) { message.textContent = "Email or password is incorrect, or you have not signed up yet."; return; }
    localStorage.setItem("nova_demo_session", email);
    showDashboard(users[email]);
  }
});
document.querySelector("#logout").addEventListener("click", () => {
  localStorage.removeItem("nova_demo_session");
  form.reset(); setMode("login"); showAuth();
});
const activeEmail = localStorage.getItem("nova_demo_session");
if (activeEmail && getUsers()[activeEmail]) showDashboard(getUsers()[activeEmail]);
