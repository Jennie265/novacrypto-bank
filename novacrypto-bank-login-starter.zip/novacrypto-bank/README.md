# NovaCrypto Bank — sign-up/login demo

This is a runnable starter website. It includes a sign-up screen, login screen, logout, and a sample dashboard.

## Run it on your computer

1. Install Node.js (LTS) from https://nodejs.org/
2. Unzip this project.
3. Open a terminal in the `novacrypto-bank` folder.
4. Run `npm install`
5. Run `npm start`
6. Open http://localhost:3000 in your browser.
7. Choose **Create account**, register with a name, email, and a unique demo password, then log in.

## Important limitations

This is a prototype, not a real bank or investment platform. The demo login stores account data in the browser's local storage and is not secure for real users. It is suitable only for trying the interface on one browser/device. The balances and holdings are fictional sample values. There are no real deposits, withdrawals, wallets, trades, or investment returns.

Do not collect customer identity documents, bank details, payment credentials, or real passwords with this prototype. Do not accept funds or advertise investment returns through it.

## Before any real-money launch

A production system needs a properly secured backend (password hashing, server-side sessions, database, rate limiting, email verification, password reset, audit logs, backups, and monitoring), independent security testing, and qualified legal/compliance advice. Depending on the services and jurisdictions, money transmission, custody, securities, AML/KYC, sanctions, consumer-protection, and other licensing/registration requirements may apply. Use regulated third-party providers for any permitted payment or custody functionality; do not store private keys or card/bank credentials yourself.
