# NovaCrypto Bank — Demo Website

This is a fictional front-end website concept. It is not a bank, broker, cryptocurrency exchange, or investment service.

## Included files
- `public/index.html` — the website page
- `public/styles.css` — responsive styling
- `package.json` — project metadata and start command
- `server.js` — small Node.js static-file server

## Run locally
Install Node.js, then run:

```sh
npm start
```

Open `http://localhost:3000`.

## Important
The portfolio amounts are sample figures only. This demo does not authenticate users, process payments, accept deposits or withdrawals, or collect financial credentials. Do not use it to represent a real regulated financial institution.
